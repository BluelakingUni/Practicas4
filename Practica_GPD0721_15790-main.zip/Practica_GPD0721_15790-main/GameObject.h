#pragma once
#include "Vector2.h"
class GameObject
{
public:
	Vector2 position;
	Vector2 forward;
};

